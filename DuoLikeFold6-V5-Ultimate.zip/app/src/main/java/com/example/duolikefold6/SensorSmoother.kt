package com.example.duolikefold6

/**
 * Lightweight exponential smoothing for motion / hinge sensor values.
 * Keeps UI animation stable without adding a dependency.
 */
class SensorSmoother(private val alpha: Float = 0.18f) {
    private var initialized = false
    private var value = 0f

    fun update(input: Float): Float {
        if (!initialized) {
            value = input
            initialized = true
        } else {
            value += (input - value) * alpha.coerceIn(0.01f, 1f)
        }
        return value
    }

    fun reset() {
        initialized = false
        value = 0f
    }
}
