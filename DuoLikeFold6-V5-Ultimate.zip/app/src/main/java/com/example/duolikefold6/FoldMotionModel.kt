package com.example.duolikefold6

/**
 * V5 motion model: smooths hinge angle and maps it to a normalized 0..1 progress.
 * Kept dependency-free so cloud builds remain reliable.
 */
class FoldMotionModel(
    private val smoothing: Float = 0.16f
) {
    private var initialized = false
    private var smoothedAngle = 0f

    fun update(angleDegrees: Float): Float {
        val angle = angleDegrees.coerceIn(0f, 180f)
        if (!initialized) {
            smoothedAngle = angle
            initialized = true
        } else {
            smoothedAngle += (angle - smoothedAngle) * smoothing.coerceIn(0.01f, 1f)
        }
        return smoothedAngle / 180f
    }

    fun angle(): Float = smoothedAngle

    fun reset() {
        initialized = false
        smoothedAngle = 0f
    }
}
