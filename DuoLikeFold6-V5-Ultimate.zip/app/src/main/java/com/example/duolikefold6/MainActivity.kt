package com.example.duolikefold6

import android.app.Activity
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var sm: SensorManager
    private var rotation: Sensor? = null
    private var hinge: Sensor? = null
    private var callback: ((Float, Float, Float?, String) -> Unit)? = null
    private var hasHingeSensor = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED)

        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        rotation = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        // Some foldables expose a hinge-angle sensor. Android does not guarantee
        // a standard hinge sensor on every device, so V3 detects it safely.
        hinge = sm.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
        hasHingeSensor = hinge != null

        setContent {
            var pitch by remember { mutableFloatStateOf(0f) }
            var roll by remember { mutableFloatStateOf(0f) }
            var hingeAngle by remember { mutableStateOf<Float?>(null) }
            var manual by remember { mutableStateOf(false) }
            var manualTilt by remember { mutableFloatStateOf(0f) }
            var manualFold by remember { mutableFloatStateOf(180f) }
            var status by remember {
                mutableStateOf(if (hasHingeSensor) "Hinge sensor detected" else "Hinge sensor unavailable")
            }

            LaunchedEffect(Unit) {
                callback = { p, r, h, s ->
                    pitch = p
                    roll = r
                    if (h != null) hingeAngle = h
                    status = s
                }
            }

            MaterialTheme {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF050505)) {
                    Column(
                        Modifier.fillMaxSize().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("DuoLike Fold6", color = Color.White, fontSize = 24.sp)
                                Text("V3 • real hinge sensor when available", color = Color.Gray, fontSize = 12.sp)
                            }
                            TextButton(onClick = { manualTilt = 0f }) {
                                Text("Reset")
                            }
                        }

                        Spacer(Modifier.height(12.dp))

                        val currentFold = if (manual) manualFold else (hingeAngle ?: 180f)
                        val currentPitch = if (manual) manualTilt else pitch
                        val currentRoll = if (manual) manualTilt * .65f else roll

                        DemoCard(
                            pitch = currentPitch,
                            roll = currentRoll,
                            fold = currentFold,
                            modifier = Modifier.weight(1f).fillMaxWidth()
                        )

                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Fold angle: %.1f°".format(currentFold),
                            color = Color.LightGray
                        )

                        if (!manual) {
                            Text(
                                if (hingeAngle != null)
                                    "正在使用系统 Hinge Angle Sensor"
                                else
                                    "当前设备未提供标准 Hinge Angle Sensor，使用 180°基准",
                                color = if (hingeAngle != null) Color(0xFF9BE7A4) else Color(0xFFFFC46B),
                                fontSize = 12.sp
                            )
                        }

                        Spacer(Modifier.height(4.dp))
                        Slider(
                            value = if (manual) manualFold else currentFold,
                            onValueChange = { if (manual) manualFold = it },
                            valueRange = 0f..180f,
                            enabled = manual
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("手动模式", color = Color.White)
                            Spacer(Modifier.width(8.dp))
                            Switch(checked = manual, onCheckedChange = { manual = it })
                        }

                        if (manual) {
                            Text("Tilt", color = Color.Gray, fontSize = 12.sp)
                            Slider(
                                value = manualTilt,
                                onValueChange = { manualTilt = it },
                                valueRange = -45f..45f
                            )
                        }

                        Text(
                            "Pitch %.1f°   Roll %.1f°".format(currentPitch, currentRoll),
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                        Text(status, color = Color.Gray, fontSize = 11.sp)
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        rotation?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        hinge?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() {
        sm.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(e: SensorEvent) {
        when (e.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> {
                val m = FloatArray(9)
                val o = FloatArray(3)
                SensorManager.getRotationMatrixFromVector(m, e.values)
                SensorManager.getOrientation(m, o)
                val p = Math.toDegrees(o[1].toDouble()).toFloat().coerceIn(-60f, 60f)
                val r = Math.toDegrees(o[2].toDouble()).toFloat().coerceIn(-60f, 60f)
                callback?.invoke(p, r, null, "Motion sensor active")
            }
            Sensor.TYPE_HINGE_ANGLE -> {
                val angle = e.values.firstOrNull()?.coerceIn(0f, 180f)
                callback?.invoke(0f, 0f, angle, "Hinge angle sensor active")
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}

@Composable
private fun DemoCard(
    pitch: Float,
    roll: Float,
    fold: Float,
    modifier: Modifier = Modifier
) {
    val rx by animateFloatAsState((-pitch * .24f).coerceIn(-15f, 15f), label = "rx")
    val ry by animateFloatAsState((roll * .30f).coerceIn(-18f, 18f), label = "ry")
    val close = (1f - fold / 180f).coerceIn(0f, 1f)

    Box(
        modifier
            .graphicsLayer {
                rotationX = rx
                rotationY = ry
                cameraDistance = 32f * density
                shadowElevation = (18f + close * 18f).dp.toPx()
            }
            .clip(RoundedCornerShape(30.dp))
            .border(1.dp, Color.White.copy(alpha = .35f), RoundedCornerShape(30.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFFFDFDFD), Color(0xFFD4D4D4), Color(0xFF686868))
                )
            )
            .padding(18.dp)
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Duo", color = Color.Black, fontSize = 28.sp)
                Text(
                    "HINGE %.0f°".format(fold),
                    color = Color.Black.copy(alpha = .55f),
                    fontSize = 12.sp
                )
            }

            Spacer(Modifier.height(12.dp))

            Box(
                Modifier.fillMaxWidth().weight(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.radialGradient(
                            listOf(
                                Color.White.copy(alpha = .98f),
                                Color(0xFFBEBEBE).copy(alpha = .70f),
                                Color(0xFF565656).copy(alpha = .55f)
                            )
                        )
                    )
            ) {
                // Center crease highlight; it becomes more pronounced while closing.
                Box(
                    Modifier.align(Alignment.Center)
                        .fillMaxHeight()
                        .width((1.5f + close * 5f).dp)
                        .background(Color.White.copy(alpha = .10f + close * .18f))
                )

                Column(
                    Modifier.fillMaxSize().padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Glass Panel", color = Color.Black, fontSize = 30.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Tilt • Parallax • Hinge",
                        color = Color.Black.copy(alpha = .55f)
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Shader V3", color = Color.Black.copy(alpha = .70f))
                Text(
                    if (close < .25f) "OPEN" else "FOLDING",
                    color = Color.Black.copy(alpha = .55f)
                )
            }
        }
    }
}
