# DuoLikeFold6 V3

Z Fold6 Android 版 DuoLikeAnimation 原型。

## V3 重点
- 自动检测 Android 标准 `TYPE_HINGE_ANGLE` 传感器
- 如果设备提供该传感器，实时读取 0°~180° 铰链角度
- 姿态 `TYPE_ROTATION_VECTOR` 实时驱动 3D Parallax
- AGSL Shader 源文件：`app/src/main/res/raw/duolike_v3.agsl`
- 折叠时增强中心折痕、暗角和玻璃响应
- 无 Hinge Angle Sensor 时安全降级，不会崩溃
- 手动模式用于调试视觉效果

## 重要说明
Android 标准 API 并不保证每台折叠机都暴露 `TYPE_HINGE_ANGLE`。
因此 V3 会运行时检测。如果 Z Fold6 固件没有向 Android 暴露这个传感器，
App 会显示 unavailable，而不会假装读取到了真实铰链角度。

## 运行
Android Studio -> Open -> 选择 DuoLikeFold6V3 -> 连接 Z Fold6 -> Run。

## 下一阶段
如果需要更接近 iOS 原项目，可以把 `duolike_v3.agsl` 接入真正的
RuntimeShader/RenderEffect 渲染链，并根据 Fold6 的实际屏幕尺寸、
折痕位置和窗口布局做左右半屏独立变形。

## V5 Ultimate
- FoldMotionModel 平滑折叠角度
- AGSL `duolike_v5.agsl`
- GitHub Actions Debug / Release 云端构建
