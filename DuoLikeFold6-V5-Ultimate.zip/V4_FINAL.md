# DuoLikeFold6 V4 Final

基于 V3 / Final Cloud 的最终增强版。

## V4 重点
- 保留 Z Fold 折叠角度自动检测
- 保留 Rotation Vector 姿态传感器
- 增加轻量传感器平滑工具，降低角度抖动
- 保留手动折叠角度模拟
- 保留原有 DuoLike 视觉效果
- GitHub Actions 自动构建 Debug APK
- GitHub Actions 同时尝试构建 Release APK（unsigned）
- JDK 17 + Gradle 8.10.2
- 不依赖本地 Android Studio 才能进行云端构建

## 云端构建
上传到 GitHub 后：
1. Actions
2. `Android APK - V4 Final`
3. Run workflow
4. 完成后下载 `DuoLikeFold6-V4-Final-APKs`

Debug APK 可直接测试安装。
Release unsigned APK 适合后续自行签名发布。

## 关于“真正 AGSL”
工程中已有 AGSL 资源；V4 保持兼容优先，避免因为不同 Android GPU / Compose 版本造成云端构建失败。
后续如果继续追求极致视觉，可单独做 Shader 强化分支，而不破坏这个稳定基线。
