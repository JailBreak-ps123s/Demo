# DuoLikeFold6 V5 Ultimate

这是 V4 Final 的进一步增强基线，目标是：
**Z Fold 系列折叠角度 + 姿态传感器 + 平滑动效 + AGSL 视觉资源 + 云端一键 APK 构建。**

## V5 新增
- `FoldMotionModel`：0°~180°角度归一化与平滑
- `duolike_v5.agsl`：折叠感知的 GPU Shader 资源
- GitHub Actions 同时构建 Debug / Release unsigned
- 保持无额外第三方依赖，优先保证云端构建稳定

## 云端构建
GitHub → Actions → `DuoLikeFold6 V5 Ultimate` → Run workflow。

完成后在 Artifacts 下载：
- `DuoLikeFold6-V5-debug.apk`
- `DuoLikeFold6-V5-release-unsigned.apk`

## 说明
AGSL 资源已经加入工程，但为了避免不同 Compose / Android GPU 环境导致构建不稳定，V5 不强制替换现有渲染链。
如果要进一步追求“原版 1:1”视觉效果，可以在这个稳定基线上继续做 Shader 渲染接入。
