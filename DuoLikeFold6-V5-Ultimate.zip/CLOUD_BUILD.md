# DuoLikeFold6 Final — 云端构建版

基于 V3 整理的最终云端构建包。

## 云端构建
1. 上传整个项目到 GitHub 仓库。
2. 打开仓库的 Actions。
3. 运行 `Android APK` workflow；推送到 `main`/`master` 也会自动构建。
4. 构建完成后，在 Artifacts 下载 `DuoLikeFold6-Final-APK`。
5. 解压即可得到 `DuoLikeFold6-Final-debug.apk`。

## 技术配置
- Kotlin + Jetpack Compose
- Android Gradle Plugin 8.7.3 / Kotlin 2.0.21（沿用 V3）
- Gradle 8.10.2
- JDK 17
- GitHub Actions
- 折叠角度传感器自动检测 + 无传感器回退
- Rotation Vector 姿态传感器
- 手动折叠角度模拟
- V3 视觉效果

## 本地
JDK 17 + Gradle 8.10.2：`gradle :app:assembleDebug`

APK：`app/build/outputs/apk/debug/app-debug.apk`
